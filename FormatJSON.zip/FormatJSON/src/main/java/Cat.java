//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

public class Cat {
    private String id = "";
    private String url = "";
    private int width = 0;
    private int height = 0;

    Cat(String id, String url, int width, int height) {
        this.setHeight(height);
        this.setId(id);
        this.setUrl(url);
        this.setWidth(width);
    }

    Cat() {
    }

    public String getUrl() {
        return this.url;
    }

    public int getHeight() {
        return this.height;
    }

    public int getWidth() {
        return this.width;
    }

    public String getId() {
        return this.id;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public String toJSON() {
        return "{\"id\":\"" + this.id + "\",\"url\":\"" + this.url + "\",\"width\":" + this.width + ",\"height\":" + this.height + "}";
    }
}
