//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

import java.util.Scanner;

public class CatSystem {
    CatSystem() {
        Save save = new Save();
        Download download = new Download(save);
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n" +
                "　 ／l、\n" +
                "ﾞ（ﾟ､ ｡ ７\n" +
                "　l、ﾞ ~ヽ\n" +
                "　じしf_, )ノ\n" +
                "Tutaj dostaniesz zdjęcia uroczych kotków!");
        System.out.println("1.Pobierz jednego kotka\n2.Pobierz wiele kotków");
        int option = scanner.nextInt();
        if (option == 1) {
            download.returnCat();
        } else {
            System.out.println("Ile kotków?");
            option = scanner.nextInt();
            download.returnCats(option);
        }

        System.out.println("Zapisać do pliku?\n1.Tak\n2.Nie");
        option = scanner.nextInt();
        if (option == 1) {
            System.out.println("Podaj nazwę pliku");
            String name = scanner.next();
            save.toJSONFile(name);
        }

    }
}
