//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Download {
    private final Save save;

    Download(Save save) {
        this.save = save;
    }

    public Save getSave() {
        return this.save;
    }

    private Cat getCat() {
        try {
            URL url = new URL("https://api.thecatapi.com/v1/images/search");
            HttpURLConnection connection = (HttpURLConnection)url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            int status = connection.getResponseCode();
            StringBuilder responseContent = new StringBuilder();
            String line;
            BufferedReader reader;
            if (status > 299) {
                reader = new BufferedReader(new InputStreamReader(connection.getErrorStream()));

                while((line = reader.readLine()) != null) {
                    responseContent.append(line);
                }

                reader.close();
            } else {
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));

                while((line = reader.readLine()) != null) {
                    responseContent.append(line);
                }
            }

            System.out.println(responseContent);
            JSONArray array = (JSONArray)(new JSONParser()).parse(responseContent.toString());
            JSONObject jsonObject = (JSONObject)array.get(0);
            connection.disconnect();
            return new Cat(jsonObject.get("id").toString(), jsonObject.get("url").toString(), Integer.parseInt(jsonObject.get("width").toString()), Integer.parseInt(jsonObject.get("height").toString()));
        } catch (ParseException | IOException var9) {
            var9.printStackTrace();
            return new Cat();
        }
    }

    public void returnCat() {
        this.save.save(this.getCat());
    }

    public void returnCats(int amount) {
        for(int i = 0; i < amount; ++i) {
            this.save.save(this.getCat());
        }

    }
}
