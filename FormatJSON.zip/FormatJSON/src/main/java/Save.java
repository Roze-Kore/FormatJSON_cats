//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class Save {
    private List<Cat> cats = new ArrayList();

    public Save() {
    }

    public List<Cat> getCats() {
        return this.cats;
    }

    public void save(Cat cat) {
        this.cats.add(cat);
    }

    public void toJSONFile(String name) {
        try {
            File file = new File(name + ".json");
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, true), StandardCharsets.UTF_8));
            String catString = "{\"cats\":[";

            for(int i = 0; i < this.getCats().size(); ++i) {
                catString = catString + ((Cat)this.getCats().get(i)).toJSON() + ",\n";
            }

            catString = catString.substring(0, catString.length() - 2);
            catString = catString + "]}";
            writer.write(catString);
            writer.close();
        } catch (IOException var6) {
            var6.printStackTrace();
        }

    }
}
